<b></b> </br> <br>[![Github](https://img.shields.io/badge/Github-Mr.AKING-dimgray?style=flat-square&logo=github)](https://github.com/AKING110)<br> [![Facebook](https://img.shields.io/badge/Facebook-AKING-blue?style=flat-square&logo=facebook)](https://www.facebook.com/Your.old.father.luQm4N0)<br> [![Whatsapp](https://img.shields.io/badge/Whatsapp-AKING-deepgreen?style=flat-square&logo=whatsapp)](https://wa.me/+923237528063)



<h1 align="center"> [MR.AKING]</h1>

<h2 align="center">  FB FILE CLONING PAID TOOL</h2>


## <b>installation</b>

🔰 _FILE CLONE OK IDZ_ 🔰

- `pkg update`
- `pkg upgrade`
- `pkg install git`
- `pkg install python`
- `pkg install python2`
- `pip install requests`
- `pip install mechanize`
- `pip install lolcat`
- `pip install bs4`
- `rm -rf File-Clone`
- `git clone https://github.com/AKING110/File-Clone.git`
- `cd File-Clone`
- `python AKING.py`
     


 ```Note : This Tools is Paid ```</br>
 [![Whatsapp](https://img.shields.io/badge/Whatsapp-AKING-deepgreen?style=flat-square&logo=whatsapp)](https://wa.me/+923237528063)
